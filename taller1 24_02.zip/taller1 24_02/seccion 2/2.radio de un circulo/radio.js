let radio = parseInt(prompt("ingrese el radio del circulo"))
const pi = 3.14

let perimetro = (radio * 2) * pi 
let area = pi * (radio ** 2)

console.log("el perimetro del circulo es de:" ,perimetro, "el area del circulo es de:" , area)