let lado = parseInt(prompt("ingrese un lado del cubo"))

let volumen = lado * lado * lado

console.log("el volumen del cubo es de:" ,volumen)