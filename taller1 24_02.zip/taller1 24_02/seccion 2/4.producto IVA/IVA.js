let precio = parseFloat(prompt("ingrese el precio del producto"))
const porcentaje = 0.19

let total = precio + (precio * porcentaje)

console.log("el precio con el IVA es de:", total)