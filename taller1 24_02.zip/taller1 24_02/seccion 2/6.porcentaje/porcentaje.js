let cantidad = parseFloat(prompt("ingrese la cantidad base"))
let porcentaje = parseFloat(prompt("ingrese el porcentaje a sacar"))

let valorP = porcentaje / 100

let total = cantidad - (cantidad * valorP)

console.log("el valor total del porcentaje sobre la base es de:", total)