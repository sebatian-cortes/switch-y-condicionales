let precio = parseFloat(prompt("ingrese el precio del producto"))
const descuento = 0.1

let total = precio - (precio * descuento)

cvonsole.log("el precio final con el descuento es de:", total)