let base = parseInt(prompt("ingrese la base del triangulo"))
let altura = parseInt(prompt("ingrese la altura del triangulo"))

let area = base * altura / 2

console.log("el area del triangulo es de:" ,area)