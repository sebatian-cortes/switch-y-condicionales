let num = parseInt(prompt("ingrese el numero del 1 al 15 que desea probar"))



        if ( num % 2 == 0 || num % 3 == 0) {
            console.log("el numero NO es primo")
        } else {
            if (num == 2 || num == 3) {
                console.log("el numero es primo")
            } else {
                console.log("el numero es primo")
            }
        }