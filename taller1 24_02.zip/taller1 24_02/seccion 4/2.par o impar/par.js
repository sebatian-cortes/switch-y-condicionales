let num = parseInt(prompt("ingrese el numero que desea probar"))

if (num % 2 == 0) {
    console.log(num , "es PAR")
} else {
    console.log(num , "es IMPAR")
}