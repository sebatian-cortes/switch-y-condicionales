let num = parseInt(prompt("ingrese el numero que desea probar"))

if (num % 5 == 0) {
    console.log("el numero SI es divisible por 5")
} else {
    console.log("el numero NO es divisible por 5")
}