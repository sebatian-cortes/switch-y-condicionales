let num1 = parseFloat(prompt("ingrese el primer angulo"))
let num2 = promptFloat(("ingrese el segundo angulo"))
let num3 = promptFloat(("ingrese el tercer angulo"))

if (num1 + num2 + num3 == 180) {
    console.log("los tres angulos SI corresponden a un triangulo")
}else{
    console.log("los tres angulos NO corresponden a un triangulo")
}