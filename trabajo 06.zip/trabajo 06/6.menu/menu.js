let eleccion = prompt("elija el numero que desee 1.huevo 2.frijoles 3.lentejas 4.sopa")


switch (eleccion) {
    case "1" :
        console.log("usted ha elegido huevo")
        break;

    case "2":
        console.log("usted ha elegido frijoles")
        break;

    case "3":
        console.log("usted ha elegido lentejas")
        break;

    case "4":
        console.log("usted ha elegido sopa")
        break;



    default:
        break;
}