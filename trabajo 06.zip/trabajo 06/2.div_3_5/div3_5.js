let num = parseFloat(prompt("ingrese el numero que necesita probar"))

if(num % 3 == 0 && num % 5 == 0){
    console.log("el numero si es divisible por 3 y 5")
}else{
    console.log("el numero no es divisible por 3 y 5")
}