let contraseña = prompt("ingrese su contraseña teniendo en cuenta los requisitos")


if(contraseña.length >= 8 && contraseña.length <=15 && contraseña.includes(" ")){
    console.log("contraseña valida")
}else{
    console.log("la contraseña no cumple con el numero de caracteres maximo 15 y minimo 8 y contener un espacio almenos")
}