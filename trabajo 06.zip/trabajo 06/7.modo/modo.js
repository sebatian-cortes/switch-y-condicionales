let nombre = prompt("ingrese su nombre")
let telefono = prompt("ingrese su telefono")
let ti = prompt("ingrese su tarjeta de identidad")

let modo = prompt("elija el modo que necesite 1.edicion 2.vizualizacion")

switch (modo) {
    case "1":
        nombre = prompt("bienvenido al modo edicion, por favor ingrese su nombre");
        telefono = prompt("ingrese su telefono"),
        ti = prompt("ingrese su tarjeta de identidad");
        console.log("sus nuevos datos son: su nombre:",nombre,"su telefono",telefono,"ti",ti);
        break;
    case "2":
        console.log("sus datos son: su nombre:",nombre,"su telefono",telefono,"ti",ti);
        break;
    

    default:
        break;
}