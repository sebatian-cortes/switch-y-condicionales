let num = parseInt(prompt("ingrese el numero que desea probar"))

let opcion1 = num % 2 == 0
let opcion2 = num % 2 < 0
let opcion3 = num % 2 > 0

switch (num) {
    case opcion1:
        console.log("el numero es par")

    case opcion2:
        console.log("el numero es impar")

    case opcion3:
        console.log("el numero es impar")    

    default:
        console.log("por favor ingrese un numero valido")
        break};