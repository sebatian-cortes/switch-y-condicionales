let num = parseInt(prompt("ingrese el numero del 1 al 15 que desea probar"))

let opcion1 = num == 2 
let opcion2 = num == 3
let opcion3 = num % 2 == 0
let opcion4 = num % 3 == 0

switch (opcion1&&opcion2&&opcion3&&opcion4) {
    case opcion1:
        console.log("el numero si es primo")

    case opcion2:
        console.log("el numero si es primo")

    case opcion3:
        console.log("el numero no es primo")
    
     case opcion4:
        console.log("el numero no es primo")


    default:
        console.log("por favor ingrese un numero valido")
        break}