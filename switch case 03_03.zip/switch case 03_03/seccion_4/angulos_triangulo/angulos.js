let num1 = parseFloat(prompt("ingrese el primer angulo"))
let num2 = prompt("ingrese el segundo angulo")
let num3 = prompt("ingrese el tercer angulo")

let opcion1 = num1 + num2 + num3 == 180
let opcion2 = num1 + num2 + num3 < 180
let opcion3 = num1 + num2 + num3 > 180

switch (opcion1&&opcion2&&opcion3) {
    case opcion1:
        console.log("los angulos si corresponden a un triangulo")

    case opcion2:
        console.log("los angulos no corresponden a un triangulo")

    case opcion3:
        console.log("los angulos no corresponden a un triangulo")    

    default:
        console.log("cifras no validas")
        break};